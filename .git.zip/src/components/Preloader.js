import React from 'react'


function Preloader() {
  return (
    <div className='preloader'>
        Loading...
    </div>
  )
}

export default Preloader